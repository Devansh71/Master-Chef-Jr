Vegetable oil for the pans

2 1/2 cups all-purpose flour

1 1/2 cups sugar

1 teaspoon baking soda

1 teaspoon fine salt

1 teaspoon cocoa powder

1 1/2 cups vegetable oil

1 cup buttermilk, at room temperature

2 large eggs, at room temperature

2 tablespoons red food coloring (1 ounce)

1 teaspoon white distilled vinegar

1 teaspoon vanilla extract

Cream Cheese Frosting, recipe follows

Crushed pecans, for garnish

Cream Cheese Frosting:

1 pound cream cheese, softened

4 cups sifted confectioners' sugar

2 sticks unsalted butter (1 cup), softened

1 teaspoon vanilla extract
